package com.example.tp4_rpg;
public class consumable{
    protected int vie;
    protected int givemana;
}