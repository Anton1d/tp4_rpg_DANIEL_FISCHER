package com.example.tp4_rpg;
public class enemy {
    protected int lifepoints;
    protected int weapondamage;
    protected int armor;
}
