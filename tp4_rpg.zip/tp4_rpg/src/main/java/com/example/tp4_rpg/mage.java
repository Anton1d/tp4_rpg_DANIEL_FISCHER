package com.example.tp4_rpg;
public class mage extends spellcaster{
    public mage(){
        weapondamage = 18;
        lifepoints = 12;
        armor = 8;
        manapoints = 12;
    }
    public void attack(){
   
    }
    
    
}
