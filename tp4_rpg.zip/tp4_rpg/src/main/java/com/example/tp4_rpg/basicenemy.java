package com.example.tp4_rpg;
public class basicenemy extends enemy{
    public basicenemy(){
        lifepoints = 12;
        weapondamage = 10;
        armor =8;
    }
    public void attack(){
   
    }
    
}

