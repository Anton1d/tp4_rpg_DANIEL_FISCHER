package com.example.tp4_rpg;
public class warior extends Hero {
    public warior(){
        weapondamage = 12;
        lifepoints = 20;
        armor = 10;
    }
    public void attack(){
     
    }
    
}
