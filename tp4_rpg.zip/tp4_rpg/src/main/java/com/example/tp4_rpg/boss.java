package com.example.tp4_rpg;
public class boss extends enemy{
    public boss(){
        lifepoints = 75;
        weapondamage= 20;
    }

    public void attack(){
   
    }
    
}