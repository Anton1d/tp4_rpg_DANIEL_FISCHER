package com.example.tp4_rpg;
public class potion extends consumable {
    public potion(){
        givemana=5;
    }
}
