package com.example.tp4_rpg;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
public class Hero {
    protected int lifepoints;
    protected int armor;
    protected int weapondamage;
    private List<potion> potion;
    private List<food> food;
    protected int arrow;
    protected int manapoints;
}


