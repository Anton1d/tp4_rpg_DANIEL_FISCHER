package com.example.tp4_rpg;
public class hunter extends Hero {
    public hunter(){
        weapondamage = 20;
        lifepoints = 12;
        armor= 8;
        arrow= 12;
    }
    public void attack(){
   
    }
}
