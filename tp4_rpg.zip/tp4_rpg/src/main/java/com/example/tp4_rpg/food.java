package com.example.tp4_rpg;
public class food extends consumable{
    public food(){
        vie =5;
    }
    
}
