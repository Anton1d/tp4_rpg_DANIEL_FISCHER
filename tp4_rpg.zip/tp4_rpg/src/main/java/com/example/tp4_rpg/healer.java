package com.example.tp4_rpg;
public class healer extends spellcaster{
    public healer(){
        weapondamage = -8;
        lifepoints= 12;
        armor= 4;
        manapoints= 12; 

    }
    public void attack(){
   
    }
}
