package com.example.tp4_rpg;
public class spellcaster extends Hero {
}
